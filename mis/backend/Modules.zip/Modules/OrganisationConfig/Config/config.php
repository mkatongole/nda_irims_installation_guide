<?php

return [
    'name' => 'OrganisationConfig'
];
