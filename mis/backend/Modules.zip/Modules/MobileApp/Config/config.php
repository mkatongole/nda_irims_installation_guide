<?php

return [
    'name' => 'MobileApp'
];
