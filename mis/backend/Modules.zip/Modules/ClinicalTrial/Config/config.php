<?php

return [
    'name' => 'ClinicalTrial'
];
