<?php

return [
    'name' => 'PremiseRegistration'
];
