<?php

return [
    'name' => 'PharmacovigilanceReporting'
];
