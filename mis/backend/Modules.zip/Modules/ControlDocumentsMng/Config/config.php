<?php

return [
    'name' => 'ControlDocumentsMng'
];
