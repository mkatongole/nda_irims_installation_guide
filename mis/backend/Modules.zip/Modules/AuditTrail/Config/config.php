<?php

return [
    'name' => 'AuditTrail'
];
