<?php

return [
    'name' => 'PromotionMaterials'
];
