<?php

return [
    'name' => 'GmpApplications'
];
