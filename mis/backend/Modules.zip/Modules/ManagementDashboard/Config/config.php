<?php

return [
    'name' => 'ManagementDashboard'
];
