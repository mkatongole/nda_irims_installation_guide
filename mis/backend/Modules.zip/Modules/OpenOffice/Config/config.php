<?php

return [
    'name' => 'OpenOffice'
];
