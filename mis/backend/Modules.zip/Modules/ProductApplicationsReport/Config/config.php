<?php

return [
    'name' => 'ProductApplicationsReport'
];
