<?php

namespace Modules\Configurations\Entities;

use Illuminate\Database\Eloquent\Model;

class SiUnits extends Model
{
    protected $table='par_si_units';
    protected $guarded=[];
    const UPDATED_AT = 'dola';
    const CREATED_AT = 'created_on';
}
