<?php

namespace Modules\Configurations\Entities;

use Illuminate\Database\Eloquent\Model;

class TypeOfvariations extends Model
{
    protected $table='par_typeof_variations';
    protected $guarded=[];
    const UPDATED_AT = 'dola';
    const CREATED_AT = 'created_on';
}
