<?php

namespace Modules\Configurations\Entities;

use Illuminate\Database\Eloquent\Model;

class TimespanDefination extends Model
{
    protected $table='par_timespan_defination';
    protected $guarded=[];
    const UPDATED_AT = 'dola';
    const CREATED_AT = 'created_on';
}
