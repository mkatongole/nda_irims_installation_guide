<?php

return [
    'name' => 'AuditReport'
];
