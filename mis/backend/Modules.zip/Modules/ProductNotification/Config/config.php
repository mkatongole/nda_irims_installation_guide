<?php

return [
    'name' => 'ProductNotification'
];
