<?php

return [
    'name' => 'ProductRegistration'
];
