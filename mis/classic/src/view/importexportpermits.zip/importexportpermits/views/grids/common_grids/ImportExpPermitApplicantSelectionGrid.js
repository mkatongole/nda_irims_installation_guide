/**
 * Created by Kip on 9/26/2018.
 */
Ext.define('Admin.view.importexportpermits.views.grids.common_grids.ImportExpPermitApplicantSelectionGrid', {
    extend: 'Admin.view.commoninterfaces.grids.ApplicantSelectionCmnGrid',
    controller: 'importexportpermitsvctr',
    xtype: 'importexppermitapplicantselectiongrid'
});
