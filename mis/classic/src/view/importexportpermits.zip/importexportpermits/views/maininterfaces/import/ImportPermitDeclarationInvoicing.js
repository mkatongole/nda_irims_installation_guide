/**
 * Created by Kip on 10/12/2018.
 */

Ext.define('Admin.view.importexportpermits.views.maininterfaces.import.ImportPermitDeclarationInvoicing', {
    extend: 'Ext.panel.Panel',
    xtype: 'importpermitdeclarationinvoicing',
    layout: 'fit',
    items:[{
        xtype: 'importpermitdeclarationinvoicingpnl'
    }]
});