/**
 * Created by Softclans
 */
Ext.define('Admin.view.importexportpermits.views.forms.common_forms.ImportExportPremisesFrm', {
    extend: 'Admin.view.commoninterfaces.forms.PremiseDetailsCmnFrm',
    xtype: 'importexportpremisesfrm',
    itemId: 'importexportpremisesfrm'
});

