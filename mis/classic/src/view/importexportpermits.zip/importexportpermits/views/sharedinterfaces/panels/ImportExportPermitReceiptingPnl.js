/**
 * Created by softclans
 * user robinson odhiambo
 * Kip on 9/24/2018. 
 */
Ext.define('Admin.view.importexportpermits.views.sharedinterfaces.panels.ImportExportPermitReceiptingPnl', {
    alias: 'widget.importexportpermitreceiptingpnl',
    extend: 'Admin.view.commoninterfaces.PaymentVerificationPnl',
    permitsdetails_panel: 'previewimportexportpermitdetails',
    itemId: 'main_processpanel'
});
